package edu.iastate.cs228.proj4;

/**
 * 
 * @author Joshua Loftus
 * 
 * 
 *         An entry tree class.
 *
 *
 */
public class EntryTree<K, V>
	{
	// Dummy root node.
	// Made public for grading.
	public Node root;
	
	/**
	 * 
	 * You are allowed to add at most TWO more data fields to EntryTree class of int
	 * type ONLY if you need to.
	 * 
	 */
	
	// All made public for grading.
	public class Node implements EntryNode<K, V>
		{
		public Node child; // reference to the first child node
		public Node parent; // reference to the parent node
		public Node prev; // reference to the previous sibling
		public Node next; // reference to the next sibling
		public K key; // the key for this node
		public V value; // the value at this node
		
		
		
		public Node(K aKey, V aValue)
			{
			key = aKey;
			value = aValue;
			child = null;
			parent = null;
			prev = null;
			next = null;
			}
			
			
			
		@Override
		public EntryNode<K, V> parent()
			{
			return parent;
			// Done
			}
			
			
			
		@Override
		public EntryNode<K, V> child()
			{
			return child;
			// Done
			}
			
			
			
		@Override
		public EntryNode<K, V> next()
			{
			return next;
			// Done
			}
			
			
			
		@Override
		public EntryNode<K, V> prev()
			{
			return prev;
			// Done
			}
			
			
			
		@Override
		public K key()
			{
			return key;
			// Done
			}
			
			
			
		@Override
		public V value()
			{
			return value;
			// Done
			}
		}
		
		
		
	public EntryTree()
		{
		root = new Node(null, null);
		}
		
		
		
	/**
	 * Returns the value of the entry with a specified key sequence, or {@code null}
	 * if this tree contains no entry with this key sequence.
	 * 
	 * This method returns {@code null} if {@code keyarr} is null or if its length
	 * is {@code 0}. If any element of {@code keyarr} is {@code null}, then the
	 * method throws a {@code NullPointerException}. The method returns the value of
	 * the entry with the key sequence in {@code keyarr} or {@code null} if this
	 * tree contains no entry with this key sequence. An example is given in
	 * provided sample input and output files to illustrate this method.
	 *
	 * @param keyarr
	 *            Read description.
	 * @return Read description.
	 * @throws NullPointerException
	 *             Read description.
	 */
	public V search(K[] keyarr)
		{
		if (keyarr == null || keyarr.length == 0)
			{
			return null;
			}
		for (int index = 0; index < keyarr.length; index++)
			{
			if (keyarr[index] == null)
				{
				throw new NullPointerException();
				}
			}
		Node node = helper(keyarr);
		if (node.value == null)
			{
			return null;
			}
		return node.value;
		// Done
		}
		
		
		
	/**
	 * 
	 * This method returns an array of type {@code K[]} with the longest prefix of
	 * the key sequence specified in {@code keyarr} such that the keys in the prefix
	 * label the nodes on the path from the root to a node. The length of the
	 * returned array is the length of the longest prefix.
	 * 
	 * This method returns {@code null} if {@code keyarr} is {@code null}, or if its
	 * length is {@code 0}. If any element of {@code keyarr} is {@code null}, then
	 * the method throws a {@code NullPointerException}. A prefix of the array
	 * {@code keyarr} is a key sequence in the subarray of {@code keyarr} from index
	 * {@code 0} to any index {@code m>=0}, i.e., greater than or equal to; the
	 * corresponding suffix is a key sequence in the subarray of {@code keyarr} from
	 * index {@code m+1} to index {@code keyarr.length-1}. The method returns an
	 * array of type {@code K[]} with the longest prefix of the key sequence
	 * specified in {@code keyarr} such that the keys in the prefix are,
	 * respectively, with the nodes on the path from the root to a node. The lngth
	 * of the returned array is the length of the longest prefix. Note that if the
	 * length of the longest prefix is {@code 0}, then the method returns
	 * {@code null}. This method can be used to select a shorted key sequence for an
	 * {@code add} command to create a shorter path of nodes in the tree. An example
	 * is given in the attachment to illustrate how this method is used with the
	 * {@code #add(K[] keyarr, V aValue)} method.
	 * 
	 * NOTE: In this method you are allowed to use {@link java.util.Arrays}'s
	 * {@code copyOf} method only.
	 * 
	 * @param keyarr
	 *            Read description.
	 * @return Read description.
	 * @throws NullPointerException
	 *             Read description.
	 */
	public K[] prefix(K[] keyarr)
		{
		Node node = root.child;
		int index = 0;
		if (keyarr == null || keyarr.length == 0)
			{
			return null;
			}
		for (int test = 0; test < 0; test++)
			{
			if (keyarr[test] == null)
				{
				throw new NullPointerException();
				}
			}
		while (node != null && index < keyarr.length)
			{
			if (node.key.equals(keyarr[index]))
				{
				node = node.child;
				index++;
				}
			else if (node.next != null && node.next.key.equals(keyarr[index]))
				{
				node = node.next;
				}
			else
				{
				node = null;
				}
			}
		K[] result = (K[]) new Object[index];
		index -= 1;
		while (index >= 0)
			{
			result[index] = keyarr[index];
			index--;
			}
		if (result.length == 0)
			{
			return null;
			}
		return result;
		// Done
		}
		
		
		
	/**
	 * This method is used and operates the exact same way that prefix does but
	 * instead of returning an array of K elements, it returns the last node of the
	 * prefix. If any on the elements of keyarr are null it will throw a
	 * NullPointerException.
	 * 
	 * @param keyarr
	 *            - an array of type K elemnts, the exact same variable that is to
	 *            be plugged into prefix() and remove().
	 * 
	 * @return lastNode - A Node, Specifically, the last node of the prefix.
	 * 
	 * @throws NullPointerException
	 *             - if an element of keyarr is equal to null.
	 */
	private Node helper(K[] keyarr)
		{
		Node node = root.child;
		int index = 0;
		Node lastNode = null;
		if (keyarr == null || keyarr.length == 0)
			{
			return null;
			}
		for (int test = 0; test < keyarr.length; test++)
			{
			if (keyarr[test] == null)
				{
				throw new NullPointerException();
				}
			}
		while (node != null && index < keyarr.length)
			{
			if (node.key.equals(keyarr[index]))
				{
				lastNode = node;
				index++;
				node = node.child;
				}
			else if (node.next != null && node.next.key.equals(keyarr[index]))
				{
				lastNode = node;
				node = node.next;
				}
			else if (index == 0 && !(node.key.equals(keyarr[index])))
				{
				return null;
				}
			else
				{
				lastNode = node;
				node = null;
				}
			}
			
		return lastNode;
		}
		
		
		
	/**
	 * 
	 * This method returns {@code false} if {@code keyarr} is {@code null}, its
	 * length is {@code 0}, or {@code aValue} is {@code null}. If any element of
	 * {@code keyarr} is {@code null}, then the method throws a
	 * {@code NullPointerException}.
	 * 
	 * This method locates the node {@code P} corresponding to the longest prefix of
	 * the key sequence specified in {@code keyarr} such that the keys in the prefix
	 * label the nodes on the path from the root to the node. If the length of the
	 * prefix is equal to the length of {@code keyarr}, then the method places
	 * {@code aValue} at the node {@code P} (in place of its old value) and returns
	 * {@code true}. Otherwise, the method creates a new path of nodes (starting at
	 * a node {@code S}) labelled by the corresponding suffix for the prefix,
	 * connects the prefix path and suffix path together by making the node
	 * {@code S} a child of the node {@code P}, and returns {@code true}. An example
	 * input and output files illustrate this method's operation.
	 *
	 * NOTE: In this method you are allowed to use {@link java.util.Arrays}'s
	 * {@code copyOf} method only.
	 * 
	 * @param keyarr
	 *            Read description.
	 * @param Read
	 *            description.
	 * @return Read description.
	 * @throws NullPointerException
	 *             Read description.
	 */
	public boolean add(K[] keyarr, V aValue)
		{
		if (keyarr == null || keyarr.length == 0 || aValue == null)
			{
			return false;
			}
		for (int index = 0; index < keyarr.length; index++)
			{
			if (keyarr[index] == null)
				{
				throw new NullPointerException();
				}
			}
		Node node = root;
		if (root.child == null)
			{
			for (int index = 0; index < keyarr.length; index++)
				{
				Node newNode = new Node(null, null);
				node.child = newNode;
				node.child.key = keyarr[index];
				node = node.child;
				if (index == 0)
					{
					root.child = newNode;
					}
				}
			node.value = aValue;
			return true;
			}
		node = root;
		K[] prefix = prefix(keyarr);
		Node backNode = helper(keyarr);
		if (backNode == null)
			{
			for (int index = 0; index < keyarr.length; index++)
				{
				Node newNode = new Node(keyarr[index], null);
				if (index == 0)
					{
					node.next = newNode;
					node = node.next;
					}
				else
					{
					node.child = newNode;
					node = node.child;
					}
				}
			node.value = aValue;
			return true;
			}
		if (keyarr.length != prefix.length && backNode != null)
			{
			node = node.child;
			
			for (int count = 0; count < prefix.length; count++)
				{
				if (node.key.equals(prefix[count]))
					{
					if (node.child != null)
						{
						node = node.child;
						}
					}
				else if (node.next != null && node.next.key.equals(prefix[count]))
					{
					node = node.next;
					count--;
					}
				}
			for (int index = 0; index < keyarr.length - prefix.length; index++)
				{
				// node = node.child;
				Node newNode = new Node(keyarr[index + prefix.length], null);
				if (index == 0 && node.child != null && node.next == null)
					{
					node.next = newNode;
					node = node.next;
					}
				else if (index == 0 && node.child != null && node.next != null)
					{
					node.next.next = newNode;
					node = node.next.next;
					}
				else
					{
					node.child = newNode;
					node = node.child;
					}
				}
			node.value = aValue;
			}
		if (keyarr.length == prefix.length)
			{
			backNode.value = aValue;
			}
		return true;
		// Done
		}
		
		
		
	/**
	 * Removes the entry for a key sequence from this tree and returns its value if
	 * it is present. Otherwise, it makes no change to the tree and returns
	 * {@code null}.
	 * 
	 * This method returns {@code null} if {@code keyarr} is {@code null} or its
	 * length is {@code 0}. If any element of {@code keyarr} is {@code null}, then
	 * the method throws a {@code NullPointerException}. The method returns
	 * {@code null} if the tree contains no entry with the key sequence specified in
	 * {@code keyarr}. Otherwise, the method finds the path with the key sequence,
	 * saves the value field of the node at the end of the path, sets the value
	 * field to {@code null}.
	 * 
	 * The following rules are used to decide whether the current node and higher
	 * nodes on the path need to be removed. The root cannot be removed. Any node
	 * whose value is not {@code null} cannot be removed. Consider a non-root node
	 * whose value is {@code null}. If the node is a leaf node (has no children),
	 * then the node is removed. Otherwise, if the node is the parent of a single
	 * child and the child node is removed, then the node is removed. Finally, the
	 * method returns the saved old value.
	 * 
	 * 
	 * @param keyarr
	 *            Read description.
	 * @return Read description.
	 * @throws NullPointerException
	 *             Read description.
	 * 
	 */
	public V remove(K[] keyarr)
		{
		if (keyarr == null || keyarr.length == 0)
			{
			return null;
			}
		for (int index = 0; index < keyarr.length; index++)
			{
			if (keyarr[index] == null)
				{
				throw new NullPointerException();
				}
			}
		Node node = helper(keyarr);
		if (node == root)
			{
			return null;
			}
		if (node != null)
			{
			V value = node.value;
			node.value = null;
			return value;
			}
		return null;
		// Done
		}
		
		
		
	/**
	 * 
	 * This method prints the tree on the console in the output format shown in
	 * provided sample output file. If the tree has no entry, then the method just
	 * prints out the line for the dummy root node.
	 * 
	 */
	public void showTree()
		{
		System.out.println("null::null");
		if (root.child != null)
			{
			Node nodeChild = root.child;
			showTree(nodeChild, 1);
			}
		if (root.next != null)
			{
			Node nodeNext = root.next;
			showTree(nodeNext, 1);
			}
		// Done
		}
		
		
		
	/**
	 * This method helps the original showTree method using recursion. It helps find
	 * how many dots to print out before printing and when nodes have multiple
	 * children.
	 * 
	 * @param node
	 *            The starting point for the method. It is the node 1 layer below
	 *            the root.
	 * @param lineNumber
	 *            Number used to calculate how many dots are needed before printing
	 *            out the nodes information.
	 */
	private void showTree(Node node, int lineNumber)
		{
		String dots = "";
		for (int count = 0; count < lineNumber; count++)
			{
			if (count == 0)
				{
				dots = "......";
				}
			else
				{
				dots += "..";
				}
			}
		if (node.child != null)
			{
			System.out.println(dots + node.key + "::" + node.value);
			showTree(node.child, lineNumber + 1);
			}
		if (node.next != null)
			{
			showTree(node.next, lineNumber + 1);
			}
		if (node.child == null && node.next == null)
			{
			System.out.println(dots + node.key + "::" + node.value);
			}
		}
		
		
		
	/**
	 * 
	 * Returns all values in this entry tree together with their keys. The order of
	 * outputs would be similar to level order traversal, i.e., first you would get
	 * all values together with their keys in first level from left to right, then
	 * second level, and so on. If tree has no values then it would return
	 * {@code null}.
	 *
	 * For the example image given in description, the returned String[][] would
	 * look as follows:
	 * 
	 * {{"IA","Grow"}, {"ISU","CS228"}}
	 * 
	 * NOTE: In this method you are allowed to use {@link java.util.LinkedList}.
	 * 
	 * 
	 */
	public String[][] getAll()
		{
		java.util.LinkedList<K> KList = new java.util.LinkedList<K>();
		java.util.LinkedList<V> VList = new java.util.LinkedList<V>();
		Node node = null;
		if (root.child != null)
			{
			node = root.child;
			}
		getAllHelper(node, KList, VList);
		if (root.next != null)
			{
			KList.add(null);
			node = root.next;
			}
		getAllHelper(node, KList, VList);
		if (VList.size() == 0)
			{
			return null;
			}
		int size = 1;
		for (int index = 0; index < KList.size(); index++)
			{
			if (KList.get(index) == null)
				{
				size++;
				}
			}
		String[][] result = new String[size][2];
		int num = 0;
		int kIndex = 0;
		for (int index = 0; index < KList.size() && num < size; index++)
			{
			if (KList.get(index) != null)
				{
				String line = "";
				while (kIndex < KList.size() && KList.get(kIndex) != null)
					{
					line += KList.get(kIndex) + "";
					kIndex++;
					}
				kIndex++;
				result[num][0] = line;
				result[num][1] = VList.get(index) + "";
				num++;
				}
			}
		return result;
		// Done
		}
		
		
		
	/**
	 * This method is a helper method to the getAll() method. It reccursivly
	 * traverses down each side of the tree and returns two seperate linked lists,
	 * one of the values and one of the keys.
	 * 
	 * @param node
	 *            This is either root.child or root.next and is the starting point
	 *            of the reccursive pattern. This is also the variable used to
	 *            traverse the entire tree.
	 * @param KList
	 *            A linked list of all the keys in the binary tree compiled by
	 *            reccursivly going through all the nodes. Compleated keys are
	 *            seperated by a null element in order to seperated them later.
	 * @param VList
	 *            A linked list of all the values in the binary tree complied by
	 *            reccursivly going through all the nodes.
	 * @return LinkedList edits then returns the linked lists from getAll() named
	 *         KList and VList respectivly. The variabls are the same for the
	 *         getAll() method.
	 */
	public java.util.LinkedList getAllHelper(Node node, java.util.LinkedList<K> KList, java.util.LinkedList<V> VList)
		{
		if (node != null)
			{
			if (node.child != null)
				{
				KList.add(node.key);
				if (node.value != null)
					{
					VList.add(node.value);
					}
				return getAllHelper(node.child, KList, VList);
				}
			if (node.next != null)
				{
				KList.add(null);
				KList.add(node.key);
				if (node.value != null)
					{
					VList.add(node.value);
					}
				return getAllHelper(node.next, KList, VList);
				}
			if (node.child == null && node.next == null && node != null)
				{
				KList.add(node.key);
				if (node.value != null)
					{
					VList.add(node.value);
					}
				return getAllHelper(null, KList, VList);
				}
			}
		return null;
		}
	}
