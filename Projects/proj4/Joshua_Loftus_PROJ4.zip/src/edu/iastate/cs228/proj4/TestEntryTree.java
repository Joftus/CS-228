/**
* Author @Josh_Lofuts
* Nov 11, 2018
*/
package edu.iastate.cs228.proj4;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import org.junit.jupiter.api.Test;

public class TestEntryTree<K, V>
	{
	
	/*
	 * 	This method test the search Method in the class EntryTree.
	 */
	@Test
	public void test01_Search()
		{
		EntryTree<K, V> expected = new EntryTree<K, V>();
		K[] KeyArr = (K[]) new Object[] {"a", "b", "c"};
		assertTrue(expected.add(KeyArr, (V) "228"));
		K[] realKeyArr = (K[]) new Object[] {"a", "b", "c", "e", "d"};
		assertEquals((V) "228", expected.search(realKeyArr));
		}
		
		
	/*
	 * 	This method test the prefix Method in the class EntryTree.
	 */
	@Test
	public void test02_Prefix()
		{
		EntryTree<K, V> expected = new EntryTree<K, V>();
		K[] KeyArr = (K[]) new Object[] {"a", "b", "c", "d", "e"};
		assertTrue(expected.add(KeyArr, (V) "228"));
		K[] expectedKeyArr = (K[]) new Object[] {"a", "b", "c"};
		K[] realKeyArr = (K[]) new Object[] {"a", "b", "c", "e", "d"};
		assertEquals(Arrays.toString(expectedKeyArr), Arrays.toString(expected.prefix(realKeyArr)));
		}
		
		
	/*
	 * 	This method test the add Method in the class EntryTree.
	 */
	@Test
	public void test03_Add()
		{
		EntryTree<K, V> expected = new EntryTree<K, V>();
		K[] KeyArr = (K[]) new Object[] {"a", "b", "c", "d", "e"};
		assertTrue(expected.add(KeyArr, (V) "228"));
		assertTrue(expected.add(KeyArr, (V) "227"));
		assertEquals((V) "227", expected.search(KeyArr));
		}
		
		
	/*
	 * 	This method test the remove Method in the class EntryTree.
	 */
	@Test
	public void test04_Remove()
		{
		EntryTree<K, V> expected = new EntryTree<K, V>();
		K[] KeyArr = (K[]) new Object[] {"a", "b", "c", "d", "e"};
		K[] KeyArr2 = (K[]) new Object[] {"c", "d", "e", "f", "g"};
		assertTrue(expected.add(KeyArr, (V) "228"));
		assertEquals(expected.remove(KeyArr), "228");
		assertEquals(null, expected.search(KeyArr));
		assertTrue(expected.add(KeyArr, (V) "228"));
		assertTrue(expected.add(KeyArr2, (V) "227"));
		assertTrue(expected.add(KeyArr, (V) "228"));
		assertEquals(expected.remove(KeyArr), "228");
		assertEquals("227", expected.search(KeyArr2));
		}
		
		
	/*
	 * 	This method test the showTree Method in the class EntryTree.
	 */
	@Test
	public void test05_ShowTree()
		{
		EntryTree<K, V> expected = new EntryTree<K, V>();
		K[] KeyArr = (K[]) new Object[] {"a", "b", "c", "d", "e"};
		K[] KeyArr2 = (K[]) new Object[] {"c", "d", "e", "f", "g"};
		V expectedValue = null;
		expected.add(null, null);
		expected.remove(null);
		assertTrue(expected.add(KeyArr2, (V) "227"));
		assertTrue(expected.add(KeyArr, (V) "228"));
		expected.showTree();
		
		}
	}
